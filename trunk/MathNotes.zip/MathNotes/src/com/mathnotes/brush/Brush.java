package com.mathnotes.brush;

import android.graphics.Path;

public class Brush implements  IBrush {
    public void mouseDown(Path path, float x, float y) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void mouseMove(Path path, float x, float y) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void mouseUp(Path path, float x, float y) {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}